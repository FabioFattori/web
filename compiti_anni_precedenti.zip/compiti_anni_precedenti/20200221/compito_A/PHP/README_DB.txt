Istruzioni per creare il database e la tabella

Andare in phpmyAdmin e andare nella voce di menu a tab "SQL".

- Creare il DB: CREATE DATABASE febbraio

- Importare tramite phpMyAdmin attraverso l'apposita tab "Importa" il file articoli.sql
