<html lang="it">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <title>Città Italiane</title>
  </head>
  <body>
    <form action="index.php" method="GET">
      <label for="citta">Città</label>
      <select name="citta">
      </select>
      <label for="tMin">Minima</label> <input type="text" size="2" name="tMin"/>
      <label for="tMax">Massima</label> <input type="text" size="2" name="tMax"/><br />
      <input type="submit" value="Invia" />
    </form>
  </body>
</html>
