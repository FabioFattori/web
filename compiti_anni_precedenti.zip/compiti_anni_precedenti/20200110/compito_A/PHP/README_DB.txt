Istruzioni per creare il database e la tabella

Andare in phpmyAdmin e andare nella voce di menu a tab "SQL".

1. Creare il DB

CREATE DATABASE climate

2. importare tramite phpMyAdmin attraverso l'apposita tab "Importa" il file temperature.sql
