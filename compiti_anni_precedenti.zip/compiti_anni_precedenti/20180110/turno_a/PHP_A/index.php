<!DOCTYPE html>
<html>
  <head>
    <title>Impiccato</title>
  </head>
  <body>
    <form action="index.php" method="post">
      <label>Lettera</label>
      <input type="text" name="lettera" id="lettera">
      <br>
      <input type="submit" value="submit">
    </form>
    <div>
    </div>
  </body>
</html>
