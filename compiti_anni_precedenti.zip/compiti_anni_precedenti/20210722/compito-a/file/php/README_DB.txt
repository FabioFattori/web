Istruzioni per creare il database e la tabella

Andare in phpmyAdmin e andare nella voce di menu a tab "SQL".


1. Creare il DB

CREATE DATABASE lotto


2. Nel file lotto.sql trovate le query di creazione della tabella e di inserimento di alcuni dati d'esempio.
