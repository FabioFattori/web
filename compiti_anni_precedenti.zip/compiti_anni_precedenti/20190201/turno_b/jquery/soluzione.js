function get_random_int(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}
